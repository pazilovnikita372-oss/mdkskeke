package com.oxide.launcher.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.oxide.launcher.ui.components.*
import com.oxide.launcher.ui.theme.*
import com.oxide.launcher.viewmodel.InstalledApp
import com.oxide.launcher.viewmodel.OxideViewModel

@Composable
fun AppsScreen(
    navController: NavHostController,
    viewModel: OxideViewModel
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    var query by remember { mutableStateOf("") }

    val filtered = uiState.installedApps.filter {
        query.isBlank() || it.name.contains(query, ignoreCase = true)
    }

    OxideBackground {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {
            OxideTopBar(title = "ПРИЛОЖЕНИЯ", onBack = { navController.popBackStack() })
            NeonDivider()

            // Search bar
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Поиск…", color = OxideTextSecond) },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = OxideNeonBlue)
                },
                trailingIcon = if (query.isNotEmpty()) {
                    { IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = null, tint = OxideTextSecond)
                    }}
                } else null,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor   = OxideNeonBlue,
                    unfocusedBorderColor = OxideGlassBorder,
                    cursorColor          = OxideNeonBlue,
                    focusedTextColor     = OxideTextPrimary,
                    unfocusedTextColor   = OxideTextPrimary
                ),
                singleLine = true
            )

            if (uiState.isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = OxideNeonBlue)
                }
            } else if (filtered.isEmpty()) {
                EmptyState(Icons.Default.SearchOff, "Нет установленных приложений\nили нет результатов поиска")
            } else {
                Text(
                    "${filtered.size} приложений",
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                    fontSize = 11.sp, color = OxideTextSecond
                )
                LazyColumn(
                    Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    items(filtered, key = { it.packageName }) { app ->
                        AppItemCard(
                            app      = app,
                            onLaunch = { viewModel.launchApp(app.packageName, context) },
                            onStore  = { viewModel.openAppInStore(app.packageName, context) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AppItemCard(
    app: InstalledApp,
    onLaunch: () -> Unit,
    onStore: () -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        onClick  = onLaunch
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (app.icon != null) {
                androidx.compose.foundation.Image(
                    bitmap = app.icon,
                    contentDescription = app.name,
                    modifier = Modifier.size(44.dp)
                )
            } else {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(com.oxide.launcher.R.drawable.ic_fn_apps),
                    contentDescription = app.name,
                    modifier = Modifier.size(44.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(app.name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    color = OxideTextPrimary, maxLines = 1)
                Text(app.packageName, fontSize = 10.sp, color = OxideTextSecond, maxLines = 1)
            }
            IconButton(onClick = onLaunch) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Запустить",
                    tint = OxideNeonBlue, modifier = Modifier.size(22.dp))
            }
            IconButton(onClick = onStore) {
                Icon(Icons.Default.OpenInNew, contentDescription = "В магазин",
                    tint = OxideTextSecond, modifier = Modifier.size(18.dp))
            }
        }
    }
}
