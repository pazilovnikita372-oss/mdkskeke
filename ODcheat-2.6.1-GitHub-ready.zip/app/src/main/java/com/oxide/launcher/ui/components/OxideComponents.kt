package com.oxide.launcher.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oxide.launcher.ui.theme.*

/** Glassmorphism card */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 16.dp,
    borderColor: Color = OxideGlassBorder,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val mod = modifier
        .clip(RoundedCornerShape(cornerRadius))
        .background(
            Brush.linearGradient(
                colors = listOf(
                    Color(0x22FFFFFF),
                    Color(0x0A0044AA)
                )
            )
        )
        .border(
            width  = 1.dp,
            brush  = Brush.linearGradient(
                colors = listOf(
                    OxideGlassBorderB,
                    OxideGlassBorder,
                    Color(0x110000FF)
                )
            ),
            shape  = RoundedCornerShape(cornerRadius)
        )
        .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)

    Column(modifier = mod, content = content)
}

/** Neon action button — the 4-icon cards on home screen */
@Composable
fun NeonActionCard(
    icon: ImageVector,
    title: String,
    subtitle: String = "→",
    accentColor: Color = OxideNeonBlue,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = modifier.padding(4.dp),
        cornerRadius = 18.dp,
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = accentColor,
                modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text       = title,
                fontSize   = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color      = OxideTextPrimary,
                lineHeight = 16.sp
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text     = subtitle,
                fontSize = 12.sp,
                color    = accentColor
            )
        }
    }
}

/** Screen header bar */
@Composable
fun OxideTopBar(
    title: String,
    onBack: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            androidx.compose.material3.IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = OxideNeonBlue
                )
            }
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text       = title,
            fontSize   = 18.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            color      = OxideTextPrimary
        )
    }
}

/** Full-screen gradient background */
@Composable
fun OxideBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(GradientStart, GradientMid, GradientEnd)
                )
            ),
        content = content
    )
}

/** Neon divider line */
@Composable
fun NeonDivider(color: Color = OxideNeonBlue, alpha: Float = 0.3f) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(color.copy(alpha = alpha))
    )
}

/** Small badge/chip */
@Composable
fun OxideBadge(text: String, color: Color = OxideNeonPurple) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.2f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) {
        Text(text = text, fontSize = 10.sp, color = color, fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp)
    }
}

/** Карточка функции с картинкой-иконкой */
@Composable
fun ImageActionCard(
    @DrawableRes iconRes: Int,
    title: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    GlassCard(modifier = modifier, cornerRadius = 20.dp, onClick = onClick) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(iconRes),
                contentDescription = title,
                modifier = Modifier.size(52.dp)
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                color = OxideTextPrimary, maxLines = 2
            )
        }
    }
}
